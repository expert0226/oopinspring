package FactoryMethodPattern;

public abstract class Animal {
	// 추상 팩토리 메소드
	abstract AnimalToy factoryMethod();
}