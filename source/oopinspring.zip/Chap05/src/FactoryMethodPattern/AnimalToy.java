package FactoryMethodPattern;

// 팩토리 메소드가 생성할 객체의 상위 클래스
public abstract class AnimalToy {
	abstract void whoami();
}