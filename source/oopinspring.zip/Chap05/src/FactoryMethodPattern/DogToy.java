package FactoryMethodPattern;

//팩토리 메소드가 생성할 객체
public class DogToy extends AnimalToy {
	public void whoami() {
		System.out.println("나는 테니스공! 강아지의 친구!");
	}
}