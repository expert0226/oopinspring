package TemplateCallbackRefactoring;

public interface IStrategy {
	public abstract void doStrategy();
}