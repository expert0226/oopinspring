package TemplateCallbackRefactoring;

public class Soldier {
	void contextMethod(String weaponSound) {
		System.out.println("전투 시작");
		executeWeapon(weaponSound).doStrategy();
		System.out.println("전투 종료");
	}

	private IStrategy executeWeapon(final String weaponSound) {
		return new IStrategy() {
			@Override
			public void doStrategy() {
				System.out.println(weaponSound);
			}
		};
	}
}