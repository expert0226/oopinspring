package TemplateCallbackRefactoring;

public class Client {
	public static void main(String[] args) {
		Soldier rambo = new Soldier();
		
		rambo.contextMethod("총! 총초종총 총! 총!");
		
		System.out.println();
		
		rambo.contextMethod("칼! 카가갈 칼! 칼!");
		
		System.out.println();
		
		rambo.contextMethod("도끼! 독독..도도독 독끼!");
	}
}