package ProxyPattern;

public interface IService {
	String doSomething();
}