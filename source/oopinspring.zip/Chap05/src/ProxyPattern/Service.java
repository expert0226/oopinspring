package ProxyPattern;

public class Service implements IService {
	public String doSomething() {
		return "서비스 짱!!!";
	}
}