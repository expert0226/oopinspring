package TemplateCallback;

public interface IStrategy {
	public abstract void doStrategy();
}