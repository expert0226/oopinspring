package DecolationPattern;

public interface IService {
	public abstract String doSomething();
}