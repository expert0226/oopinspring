package AdapterPattern;

public class ServiceB {
	void doServiceB() {
		System.out.println("ServiceB");
	}
}