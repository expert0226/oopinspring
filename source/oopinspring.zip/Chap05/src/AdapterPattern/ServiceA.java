package AdapterPattern;

public class ServiceA {
	void doServiceA() {
		System.out.println("ServiceA");
	}
}