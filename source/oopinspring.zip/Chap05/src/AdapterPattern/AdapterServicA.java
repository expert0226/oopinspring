package AdapterPattern;

public class AdapterServicA {
	ServiceA sa1 = new ServiceA();
	
	void service() {		
		sa1.doServiceA();
	}
}