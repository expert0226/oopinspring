package AdapterPattern;

public class AdapterServicB {
	ServiceB sb1 = new ServiceB();
	
	void service() {		
		sb1.doServiceB();
	}
}