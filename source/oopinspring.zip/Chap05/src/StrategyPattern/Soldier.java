package StrategyPattern;

public class Soldier {
	void contextMethod(IStrategy strategy) {
		System.out.println("전투 시작");
		strategy.doStrategy();
		System.out.println("전투 종료");
	}
}