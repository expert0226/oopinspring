package StrategyPattern;

public class StrategySword implements IStrategy {
	@Override
	public void doStrategy() {
		System.out.println("챙.. 채쟁챙 챙챙");
	}
}