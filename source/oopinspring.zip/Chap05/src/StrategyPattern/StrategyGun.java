package StrategyPattern;

public class StrategyGun implements IStrategy {
	@Override
	public void doStrategy() {
		System.out.println("탕, 타당, 타다당");
	}
}