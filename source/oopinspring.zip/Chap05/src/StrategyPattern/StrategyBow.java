package StrategyPattern;

public class StrategyBow implements IStrategy {
	@Override
	public void doStrategy() {
		System.out.println("슝.. 쐐액.. 쇅, 최종 병기");
	}
}