public class Start4 {
	public static void main(String[] args) {
		int k = 5;
		int m;
		
		m = square(k);		
	}

	private static int square(int k) {
		int result;
		
		k = 25;
				
		result = k;
		
		return result;
	}
}