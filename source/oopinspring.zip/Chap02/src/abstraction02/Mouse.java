package abstraction02;

public class Mouse {
   public String name;
   public int age;
   public static int countOfTail = 1;
   //public final static int countOfTail = 1;
   public static int countOfObjects;
   
   public void sing() {
      System.out.println(name + " 찍찍!!!");
   }
}