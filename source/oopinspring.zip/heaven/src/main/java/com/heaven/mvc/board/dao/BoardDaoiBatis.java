package com.heaven.mvc.board.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.stereotype.Repository;

import com.heaven.mvc.board.domain.BoardVO;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository
public class BoardDaoiBatis implements BoardDao {
	private SqlMapClientTemplate sqlMapClinetTemplate;
	
	@Autowired
	public void setSqlMapClient(SqlMapClient sqlMapClient) {
		this.sqlMapClinetTemplate = new SqlMapClientTemplate(sqlMapClient);
	}
	
	@Override
	public List<BoardVO> list() {
		return sqlMapClinetTemplate.queryForList("list");
	}

	@Override
	public int delete(BoardVO boardVO) {		
		return sqlMapClinetTemplate.delete("delete", boardVO);
	}

	@Override
	public int deleteAll() {
		return sqlMapClinetTemplate.delete("deleteAll");
	}

	@Override
	public int update(BoardVO boardVO) {
		return sqlMapClinetTemplate.update("update", boardVO);
	}

	@Override
	public void insert(BoardVO boardVO) {
		int seq = (Integer)sqlMapClinetTemplate.insert("insert", boardVO);
		boardVO.setSeq(seq);
	}

	@Override
	public BoardVO select(int seq) {
		BoardVO vo = (BoardVO)sqlMapClinetTemplate.queryForObject("select", seq);
		return vo;
	}

	@Override
	public int updateReadCount(int seq) {
		return sqlMapClinetTemplate.update("updateCount", seq);
	}
}