INSERT INTO BOARD (title, content, writer, password, regDate, cnt) 
VALUES ('t1', 'c1', 'w1', 1234, '2013-09-09 14:21:12', 0);

INSERT INTO BOARD (title, content, writer, password, regDate, cnt) 
VALUES ('t2', 'c2', 'w1', 1234, '2013-09-09 14:21:12', 1);

INSERT INTO BOARD (title, content, writer, password, regDate, cnt) 
VALUES ('t3', 'c3', 'w1', 1234, '2013-09-09 14:21:12', 2);

INSERT INTO BOARD (title, content, writer, password, regDate, cnt) 
VALUES ('t4', 'c4', 'w1', 1234, '2013-09-09 14:21:12', 3);

INSERT INTO BOARD (title, content, writer, password, regDate, cnt) 
VALUES ('t5', 'c5', 'w1', 1234, '2013-09-09 14:21:12', 4);

INSERT INTO BOARD (title, content, writer, password, regDate, cnt) 
VALUES ('t6', 'c5', 'w1', 1234, '2013-09-09 14:21:12', 5);

INSERT INTO BOARD (title, content, writer, password, regDate, cnt) 
VALUES ('t7', 'c5', 'w1', 1234, '2013-09-09 14:21:12', 6);