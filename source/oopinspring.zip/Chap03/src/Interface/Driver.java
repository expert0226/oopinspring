package Interface;

interface Speakable {
	double pi = 3.14159;
	final double absoluteZeroPoint = -275.15;
	
	void sayYes();
}

/*
interface Speakable {
	public static double pi = 3.14159;
	public static final double absoluteZeroPoint = -275.15;
	
	public abstract void sayYes();
}
*/

class Specker implements Speakable {
	public void sayYes() {
		System.out.println("I say NO!!!");
	}
}

public class Driver {
	public static void main(String[] args) {
		System.out.println(Speakable.absoluteZeroPoint);
		System.out.println(Speakable.pi);
		
		Specker reporter1 = new Specker();
		reporter1.sayYes();
	}
	
	public static void test() {
		//에러: The final field Speakable.pi cannot be assigned
		//Speakable.pi = 3.15;
		
		//에러: The final field Speakable.absoluteZeroPoint cannot be assigned
		//Speakable.absoluteZeroPoint = -275.0;
	}
}