package FinalClass;

public final class 고양이 { }

//final 클래스는 상위 클래스가 될 수 없습니다.
//class 길고양이 extends 고양이 {}