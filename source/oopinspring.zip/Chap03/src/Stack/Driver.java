package Stack;

class 펭귄 {
	void test() {
		System.out.println("Test");
	}
}

public class Driver {
	public static void main(String[] args) {
		펭귄 뽀로로 = new 펭귄();
		
		뽀로로.test();
	}	
}