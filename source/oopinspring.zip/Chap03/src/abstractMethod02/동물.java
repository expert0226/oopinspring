package abstractMethod02;

public abstract class 동물 {
	abstract void 울어보세요();
}