package abstractMethod02;

public class 기린 extends 동물 {
	void 울어보세요() {
		System.out.println("나는 이광수? 배신? 배신?");
	}
}