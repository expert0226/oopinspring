package constructor03;

public class 동물 {
	public 동물(String name) {
		System.out.println(name);
	}
}