package constructor03;

public class Driver02 {
	public static void main(String[] args) {
		동물 뽀로로 = new 동물("뽀로로");
		//동물 무명 = new 동물(); // 주석 푸시면 바로 컴파일 에러 발생
	}
}