package constructor01;

public class 동물 {

}