public class B004 {
	public static void main(String[] args) {
		Runnable r = () -> System.out.println("Hello Rambda 4!!!");

		r.run();
	}
}