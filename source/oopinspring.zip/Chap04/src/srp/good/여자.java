package srp.good;

public class 여자 {

}
