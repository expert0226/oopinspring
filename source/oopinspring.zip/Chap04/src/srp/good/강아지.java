package srp.good;

public abstract class 강아지 {
	abstract void 소변보다();
}