package expert004;

public class Door {
}
