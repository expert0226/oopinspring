package aop006;

public interface IPerson {
	void housework();
}
