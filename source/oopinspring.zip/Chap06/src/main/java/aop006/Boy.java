package aop006;

import org.springframework.stereotype.Component;

@Component
public class Boy implements IPerson {
	public void housework() {
		System.out.println("컴퓨터로 게임을 한다.");
	}
}
