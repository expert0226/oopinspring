package expert005;

public interface Tire {
	String getBrand();
}