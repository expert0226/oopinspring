package abstraction003;

public class 동물 {
	String myClass;
	
	동물() {
		myClass = "동물";
		
	}
	
	void showMe() {
		System.out.println(myClass);
	}
}