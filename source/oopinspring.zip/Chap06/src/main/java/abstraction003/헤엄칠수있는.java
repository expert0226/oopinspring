package abstraction003;

public interface 헤엄칠수있는 {
	void swim();
}