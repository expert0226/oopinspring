package abstraction002;

public class 조류 extends 동물 {
	조류() {
		myClass = "조류";
		
	}
}