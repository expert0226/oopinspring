package aop003;

public interface IPerson {
	void housework();
}
