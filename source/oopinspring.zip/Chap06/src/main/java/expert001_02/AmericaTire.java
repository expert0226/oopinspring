package expert001_02;

public class AmericaTire implements Tire {
	public String getBrand() {
		return "미쿡 타이어";
	}
}