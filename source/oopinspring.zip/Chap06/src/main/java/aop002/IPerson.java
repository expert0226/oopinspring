package aop002;

public interface IPerson {
	void housework();
}
