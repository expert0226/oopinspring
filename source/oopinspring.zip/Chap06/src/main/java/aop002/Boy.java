package aop002;

public class Boy implements IPerson {
	public void housework() {
		System.out.println("컴퓨터로 게임을 한다.");
	}
}
