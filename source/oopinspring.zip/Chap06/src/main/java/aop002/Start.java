package aop002;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Start {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("expert.xml", Start.class);

		IPerson romeo = context.getBean("boy", IPerson.class);
		IPerson juliet = context.getBean("girl", IPerson.class);

		romeo.housework();
		juliet.housework();
	}
}