package expert003;

public interface Tire {
	String getBrand();
}