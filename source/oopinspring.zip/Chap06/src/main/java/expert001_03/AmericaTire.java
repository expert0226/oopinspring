package expert001_03;

public class AmericaTire implements Tire {
	public String getBrand() {
		return "미쿡 타이어";
	}
}