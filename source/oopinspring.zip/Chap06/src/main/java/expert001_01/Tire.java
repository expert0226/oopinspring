package expert001_01;

interface Tire {
	String getBrand();
}