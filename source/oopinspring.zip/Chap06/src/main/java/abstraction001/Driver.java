package abstraction001;

public class Driver {
	public static void main(String[] args) {
		Mouse mickey = new Mouse();
		
		mickey.name = "미키마우스";
		mickey.nationality = "미국";
		mickey.age = 85;
		
		mickey.sing();
	}
}
