package aop004;

public interface IPerson {
	void housework();
}
