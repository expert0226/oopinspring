package aop004;

public class Girl implements IPerson {
	public void housework() {
		System.out.println("요리를 한다.");
	}
}