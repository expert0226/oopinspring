package aop005;

public class Girl implements IPerson {
	public void housework() {
		System.out.println("요리를 한다.");
	}
}