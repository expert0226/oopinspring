package aop005;

public interface IPerson {
	void housework();
}
