package expert006;

//tire 인터페이스를 구현하지 않음
public class Door {

}
